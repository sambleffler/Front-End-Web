/*Code for menu button found at w3school.com*/
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}


function q1(){
	
	$( this ).siblings(".answer").show(500);

	var i = parseInt(document.getElementById("quiz1").value);

	if (i == 100) {
		$( this ).siblings(".correct").show(500);
		$( this ).siblings(".incorrect").hide(500);
		$( this ).siblings(".close").hide(500);
	}

	if (i >= 85 && i<= 115) {
		$( this ).siblings(".incorrect").hide(500);
		$( this ).siblings(".correct").hide(500);
		$( this ).siblings(".close").show(500);
	}

	else{
		$( this ).siblings(".incorrect").show(500);
		$( this ).siblings(".correct").hide(500);
		$( this ).siblings(".close").hide(500);
	}

	
}

function russia(){
	$( this ).siblings(".answer").show(500);
	$( this ).siblings(".correct").show(500);
	$( this ).siblings(".incorrect").hide(500);
	$('#USA').animate({opacity: 0.5}, 500);
	$('#Russia').animate({opacity: 1.0}, 500);
}

function usa(){
	$( this ).siblings(".answer").show(500);
	$( this ).siblings(".incorrect").show(500);
	$( this ).siblings(".correct").hide(500);
	$('#Russia').animate({opacity: 0.5}, 500);
	$('#USA').animate({opacity: 1.0}, 500);
}

function q3(){
	
	$( this ).siblings(".answer").show(500);

	var i = parseInt(document.getElementById("quiz3").value);

	if (i == 32) {
		$( this ).siblings(".correct").show(500);
		$( this ).siblings(".incorrect").hide(500);
		$( this ).siblings(".close").hide(500);

	}

	if (i != 32) {
		if (i >= 27 && i<=37){
			$( this ).siblings(".incorrect").hide(500);
			$( this ).siblings(".correct").hide(500);
			$( this ).siblings(".close").show(500);
		}

		else{
			$( this ).siblings(".incorrect").show(500);
			$( this ).siblings(".correct").hide(500);
			$( this ).siblings(".close").hide(500);
		}

	}

	
}

function q4(){
	
	$( this ).siblings(".answer").show(500);

	var i = parseInt(document.getElementById("quiz4").value);

	if (i >= 25 && i <= 30) {
		$( this ).siblings(".correct").show(500);
		$( this ).siblings(".incorrect").hide(500);
	}

	else {
		$( this ).siblings(".incorrect").show(500);
		$( this ).siblings(".correct").hide(500);
	}

	
}

function sAfrica(){
	$( this ).parent().siblings(".answer").show(500);
	$( this ).parent().siblings(".correct").show(500);
	$( this ).parent().siblings(".incorrect").hide(500);
	$('#Iraq').animate({opacity: 0.5}, 500);
	$('#Libya').animate({opacity: 0.5}, 500);
	$('#Japan').animate({opacity: 0.5}, 500);
	$('#SouthAfrica').animate({opacity: 1.0}, 500);
}

function iraq(){
	$( this ).parent().siblings(".answer").show(500);
	$( this ).parent().siblings(".incorrect").show(500);
	$( this ).parent().siblings(".correct").hide(500);
	$('#Libya').animate({opacity: 0.5}, 500);
	$('#SouthAfrica').animate({opacity: 0.5}, 500);
	$('#Japan').animate({opacity: 0.5}, 500);
	$('#Iraq').animate({opacity: 1.0}, 500);
}

function libya(){
	$( this ).parent().siblings(".answer").show(500);
	$( this ).parent().siblings(".incorrect").show(500);
	$( this ).parent().siblings(".correct").hide(500);
	$('#Libya').animate({opacity: 1.0}, 500);
	$('#SouthAfrica').animate({opacity: 0.5}, 500);
	$('#Japan').animate({opacity: 0.5}, 500);
	$('#Iraq').animate({opacity: 0.5}, 500);
}

function japan(){
	$( this ).parent().siblings(".answer").show(500);
	$( this ).parent().siblings(".incorrect").show(500);
	$( this ).parent().siblings(".correct").hide(500);
	$('#Libya').animate({opacity: 0.5}, 500);
	$('#SouthAfrica').animate({opacity: 0.5}, 500);
	$('#Japan').animate({opacity: 1.0}, 500);
	$('#Iraq').animate({opacity: 0.5}, 500);
}

function cc1956(){
	$('#Suez').show(500);
	$('#Suez').siblings().hide(500);
}

function cc1962(){
	$('#Cuba').show(500);
	$('#Cuba').siblings().hide(500);
}

function cc1979(){
	$('#training').show(500);
	$('#training').siblings().hide(500);
}

function cc1983(){
	$('#solar').show(500);
	$('#solar').siblings().hide(500);
}

function cc1995(){
	$('#Norway').show(500);
	$('#Norway').siblings().hide(500);
}

function cc2013(){
	$('#investigation').show(500);
	$('#investigation').siblings().hide(500);
}

function ccClick(){
	$(this).css('background-color', 'red');
	$(this).siblings('button').css('background-color', 'black');
}

function nonSig1(){

	$(this).children("p").animate({width: 'toggle'}, 500);
}

function nonSig2(){

	$(this).children("p").animate({width: 'toggle'}, 500);
}

$(document).ready(function(){
	$('#quiz1').parent().siblings(".submitButton").click(q1);
	$('#quiz3').parent().siblings(".submitButton").click(q3);
	$('#quiz4').parent().siblings(".submitButton").click(q4);
	$('#quiz6').parent().siblings(".submitButton").click(q6);
	$('#next').click(nextSlide);
	$('#last').click(lastSlide);
	$('#Russia').click(russia);
	$('#USA').click(usa);
	$('#Iraq').click(iraq);
	$('#Libya').click(libya);
	$('#SouthAfrica').click(sAfrica);
	$('#Japan').click(japan);
	$('#1956').click(cc1956);
	$('#1962').click(cc1962);
	$('#1979').click(cc1979);
	$('#1983').click(cc1983);
	$('#1995').click(cc1995);
	$('#2013').click(cc2013);
	$('#ccButtons').children('button').click(ccClick);
	$('.non').mouseenter(nonSig1).mouseleave(nonSig2);
});

function q6(){
	
	$( this ).siblings(".answer").show(500);

	var i = parseInt(document.getElementById("quiz6").value);

	if (i >= 300 && i <= 400 ) {
		if (i == 348){
		$( this ).siblings(".close").hide(500);
		$( this ).siblings(".incorrect").hide(500);
		$( this ).siblings(".correct").show(500);
		}
		
		else{
			$( this ).siblings(".correct").hide(500);
			$( this ).siblings(".incorrect").hide(500);
			$( this ).siblings(".close").show(500);
		}
	}

	else {
		$( this ).siblings(".incorrect").show(500);
		$( this ).siblings(".correct").hide(500);
		$( this ).siblings(".close").hide(500);
	}

	
}

var years = [1945, 1949, 1952, 1960, 1964, 1974, 1979, 1991, 1998, 2006, 2017];
var weapons = [2, 300, 2500, 20300, 37700, 47500, 54400, 52000, 31000, 25700, 15000];
var slides = ["img/1945.png", "img/1949.png", "img/1952.png", "img/1960.png", "img/1964.png", "img/1974.png", "img/1979.png", "img/1991.png", "img/1998.png", "img/2006.png", "img/2017.png"];
var slideCounter = 0;

/* Code for countdown animation found at https://stackoverflow.com/questions/16994662/count-animation-from-number-a-to-b*/
function animateValue(id, start, end, duration) {
    // assumes integer values for start and end

    var obj = document.getElementById(id);
    var range = end - start;
    // no timer shorter than 50ms (not really visible any way)
    var minTimer = 50;
    // calc step time to show all interediate values
    var stepTime = Math.abs(Math.floor(duration / range));

    // never go below minTimer
    stepTime = Math.max(stepTime, minTimer);

    // get current time and calculate desired end time
    var startTime = new Date().getTime();
    var endTime = startTime + duration;
    var timer;

    function run() {
        var now = new Date().getTime();
        var remaining = Math.max((endTime - now) / duration, 0);
        var value = Math.round(end - (remaining * range));
        obj.innerHTML = value;
        if (value == end) {
            clearInterval(timer);
        }
    }

    var timer = setInterval(run, stepTime);
    run();
}

function nextSlide(){
	
	var prev = slideCounter;

	if (slideCounter >= 10) {
		slideCounter = 0;
	}

	else{
		slideCounter ++;
	}

	$("#mapSlides").css("background-image", "url('"+slides[slideCounter]+"')");
	animateValue("year", years[prev], years[slideCounter], 1000);
	animateValue("stockpile", weapons[prev], weapons[slideCounter], 1000);
	console.log(slideCounter);
}


function lastSlide(){

	var prev = slideCounter;

	if (slideCounter <= 0) {
		slideCounter = 10;
	}

	else{
		slideCounter --;
	}

	$("#mapSlides").css("background-image", "url('"+slides[slideCounter]+"')");
	animateValue("year", years[prev], years[slideCounter], 1000);
	animateValue("stockpile", weapons[prev], weapons[slideCounter], 1000);
	console.log(slideCounter);
}