$(document).ready(function(){
	$("#go").click(timer);
	$("#A").click(checkAnswer);
	$("#B").click(checkAnswer);
	$("#C").click(checkAnswer);
	$("#D").click(checkAnswer);
	$("#sendScore").click(sendScore);
    
});

var score=0;

var breed;
var option1, option2, option3;
var correctAnswer;


$("#scoreBoard").innerHTML=score;

function getData(){
	//shorthand get method that loads JSON data from the server using a GET request and calls the success function
//    $.ajax({
//    type: "GET",
//    url: "https://dog.ceo/api/breeds/list",
//    data: {},
//    xhrFields: {
//        withCredentials: true
//    },
//    crossDomain: true,
//    dataType: 'json',
//    success: successfn1
//});
	$.getJSON("https://dog.ceo/api/breeds/list?", successfn1)
}

function successfn1(result){
	

	var i= Math.floor(Math.random() * result.message.length);
	var j= Math.floor(Math.random() * result.message.length);
	var k= Math.floor(Math.random() * result.message.length);
	var l= Math.floor(Math.random() * result.message.length);

	
	// ensure two identical options do not show up
	while(i==j || i==k || i==l || j==k || j==l || k==l){

		var i= Math.floor(Math.random() * result.message.length);
		var j= Math.floor(Math.random() * result.message.length);
		var k= Math.floor(Math.random() * result.message.length);
		var l= Math.floor(Math.random() * result.message.length);

	}

	breed = result.message[i];
	option1 = result.message[j];
	option2 = result.message[k];
	option3 = result.message[l];
	correctAnswer = Math.floor(Math.random() * 4);


	if (correctAnswer == 0) {
		document.getElementById("A").innerHTML = breed;
		document.getElementById("B").innerHTML = option1;
		document.getElementById("C").innerHTML = option2;
		document.getElementById("D").innerHTML = option3;
	}

	if (correctAnswer == 1) {
		document.getElementById("B").innerHTML = breed;
		document.getElementById("A").innerHTML = option1;
		document.getElementById("C").innerHTML = option2;
		document.getElementById("D").innerHTML = option3;
	}

	if (correctAnswer == 2) {
		document.getElementById("C").innerHTML = breed;
		document.getElementById("A").innerHTML = option1;
		document.getElementById("B").innerHTML = option2;
		document.getElementById("D").innerHTML = option3;
	}

	if (correctAnswer == 3) {
		document.getElementById("D").innerHTML = breed;
		document.getElementById("B").innerHTML = option1;
		document.getElementById("C").innerHTML = option2;
		document.getElementById("A").innerHTML = option3;
	}


	$.getJSON("https://dog.ceo/api/breed/"+ breed +"/images/random", successfn2);


	
}

function successfn2(result){

	//result will be a parsed JavaScript object
	console.log(result);
	
	//remove all child nodes in the update div
	$("#update").empty();
	
	//append a paragraph to the update div
	$("#update").append("<p>");	

	console.log(result.message);

	$("#update p").append("<img src='" + result.message + "'>");
	

}

function checkAnswer(){
	if ((this.id=="A" && correctAnswer == 0) || (this.id=="B" && correctAnswer == 1) || (this.id=="C" && correctAnswer == 2) || (this.id=="D" && correctAnswer == 3)) {
		score++;
		getData();
	}

	else{
		getData();
	}
	document.getElementById("scoreBoard").innerHTML = score;
	console.log(score);

}

//timer function adapted from W3 Schools
function timer(){
		
	$("#gameContainer").show();
	$("#go").hide();
	$("#submitScore").hide();
	score = 0;
	getData();
	//scroll function found at abeautifulsite.net
	$('html, body').animate({
    	scrollTop: $("#stats").offset().top
	}, 1000);

	// Set the date we're counting down to
	var countDownDate = new Date().getTime()+62000;

	// Update the count down every 1 second
	var x = setInterval(function() {

	    // Get todays date and time
	    var now = new Date().getTime();
	    
	    // Find the distance between now an the count down date
	    var distance = countDownDate - now;
	    
	    
	    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
	    
	    
	    document.getElementById("timer").innerHTML = seconds + "s ";
	    
	    // If the count down is over, write some text 
	    if (distance < 0) {
	        clearInterval(x);
	        document.getElementById("timer").innerHTML = "--";
	        $("#gameContainer").hide();
	        $("#go").show();

	        document.getElementById("displayScore").innerHTML = "Score: " +score;

	        $("#submitScore").show();
	    }
	}, 1000);
}

// Get a reference to the database service
var database = firebase.database();

// Create a storage reference from our database
var storageRef = database.ref();

function sendScore(){

	var name = document.getElementById("name").value;
	var sentScore = score;
	var rank= 100 - score;

	//write to firebase
	storageRef.push({
		name: name, 
		score: sentScore,
		rank: rank
		});
}

//function found at ilikenerds.com
function snapshotToArray(snapshot) {
    var returnArr = [];

    snapshot.forEach(function(childSnapshot) {
        var item = childSnapshot.val();
        item.score = childSnapshot.val().score;
        item.name = childSnapshot.val().name;

        returnArr.push(item);
    });

    return returnArr;
};

var scoresArray=[];



var rankedData= database.ref().orderByChild('rank');


var ranksList = document.getElementById("ranks");
var standing = 1;
var prevScore;

// rankedData.on("child_added", function(snapshot){
// 		console.log(snapshot.val());
		
// 		var HSname=snapshot.val().name;
// 		var HSscore=snapshot.val().score;
// 		ranksList.innerHTML += "<span>"+ standing+". " + HSname + "</span>..........<span>" + HSscore + "</span><br>";
// 		standing++;
// });

firebase.database().ref().orderByChild('rank').on('value', function(snapshot) {
    scoresArray = snapshotToArray(snapshot);
    console.log(scoresArray);
    
    $("#ranks").empty();

    for (var i =0; i < scoresArray.length; i++) {
	
	if(i == 0){
		ranksList.innerHTML += "<span>"+ standing+". " + scoresArray[i].name + "</span> .......... <span>" + scoresArray[i].score + "</span><br>";
		prevScore = scoresArray[i].score;
	}

	else{
		if (scoresArray[i].score == prevScore) {
			ranksList.innerHTML += "<span>"+ standing+". " + scoresArray[i].name + "</span> .......... <span>" + scoresArray[i].score + "</span><br>"
		}

		else{
			standing = i+1;
			ranksList.innerHTML += "<span>"+ standing+". " + scoresArray[i].name + "</span> .......... <span>" + scoresArray[i].score + "</span><br>";
			prevScore = scoresArray[i].score;
		}
	}
	
}
});


