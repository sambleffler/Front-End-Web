var wSlides = ["img/Akita.jpg", "img/Boxer.jpg", "img/Great-Pyrenees.jpg"];
var wNames = ["Boxer", "Great Pyrenees", "Akita"];
var hSlides = ["img/Australian-Cattle-Dog.jpg", "img/Border-Collie.jpg", "img/old-english-sheepdog-hero.jpg"];
var hNames = ["Border Collie", "Old English Sheepdog", "Australian Cattle Dog"];
var sSlides = ["img/Golden-Retriever.jpg", "img/Irish_Setter.jpg", "img/Labrador-Retriever.jpg"];
var sNames = ["Irish Setter", "Labrador Retriever", "Golden Retriever"];
var slideCounter = 0;

function showGroupW(){
	if ($("#working").css('display') == 'none'){
		$("#working").show(500);
		$("#sporting").hide(500);
		$("#herding").hide(500);
	}
	else{
		$('.group').hide(500);
	}
}

function showGroupS(){
	if ($("#sporting").css('display') == 'none'){
		$("#working").hide(500);
		$("#sporting").show(500);
		$("#herding").hide(500);
	}
	else{
		$('.group').hide(500);
	}
}

function showGroupH(){
	if ($("#herding").css('display') == 'none'){
		$("#working").hide(500);
		$("#sporting").hide(500);
		$("#herding").show(500);
	}
	else{
		$('.group').hide(500);
	}
}



function wSwitchImage(){
	$('#wImg').animate({opacity: 0.0}, 500, function(){
		if(slideCounter<2){
			slideCounter++;
		} else {
			slideCounter=0;
		}
		$('#wImg').attr("src", wSlides[slideCounter]) .animate({opacity: 1.0}, 500);
	});
	$(this).siblings('h3').html(wNames[slideCounter]);
}

function sSwitchImage(){
	$('#sImg').animate({opacity: 0.0}, 500, function(){
		if(slideCounter<2){
			slideCounter++;
		} else {
			slideCounter=0;
		}
		$('#sImg').attr("src", sSlides[slideCounter]) .animate({opacity: 1.0}, 500);
	});
	$(this).siblings('h3').html(sNames[slideCounter]);
}

function hSwitchImage(){
	$('#hImg').animate({opacity: 0.0}, 500, function(){
		if(slideCounter<2){
			slideCounter++;
		} else {
			slideCounter=0;
		}
		$('#hImg').attr("src", hSlides[slideCounter]) .animate({opacity: 1.0}, 500);
	});
	$(this).siblings('h3').html(hNames[slideCounter]);
}


$(document).ready(function(){
	$('#wHead').click(showGroupW);
	$('#hHead').click(showGroupH);
	$('#sHead').click(showGroupS);
	$("#wNext").click(wSwitchImage);
	$("#sNext").click(sSwitchImage);
	$("#hNext").click(hSwitchImage);
});
