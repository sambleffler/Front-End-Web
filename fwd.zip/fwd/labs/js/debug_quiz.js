
function quiz(){
	var score = 0;
	var question;
	var answer;
	var quiz_questions = [
	  'How many moons does Earth have?',
	  'How many moons does Saturn have?',
	  'How many moons does Venus have?'];
	var quiz_answers=[1, 31, 1];
	
	//get total number of questions
	var totalQuestion=quiz_questions.length - 1;

		
	for(count=0; count<=totalQuestion; count++){
		question=quiz_questions[count];
		answer=prompt(question);
		if (answer==quiz_answers[count]){
			score++;
			alert("Correct!");
		}
		else {
			alert("Wrong");
		}
	}

	document.write('<p>You got ' + score + ' out of ' + quiz_questions.length + ' questions correct.</p>');
}
