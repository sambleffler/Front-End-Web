var map1, map2;
  function initMap() {
    map2 = new google.maps.Map(document.getElementById('map2'), {
      zoom: 3,
      center: {lat: 10, lng: -180},
      mapTypeId: 'terrain'
    });

    map1 = new google.maps.Map(document.getElementById('map1'), {
      zoom: 3,
      center: {lat: 10, lng: -180},
      mapTypeId: 'terrain'
    });

    var script = document.createElement('script');

    script.src = 'http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_week.geojsonp';
    $('head')[0].appendChild(script);

    map2.data.setStyle(function(feature) {
      var magnitude = feature.getProperty('mag');
      return {
        icon: getCircle(magnitude)
      };
    });
  }

  function getCircle(magnitude) {
    return {
      path: google.maps.SymbolPath.CIRCLE,
      fillColor: 'red',
      fillOpacity: .2,
      scale: Math.pow(2, magnitude) / 2,
      strokeColor: 'white',
      strokeWeight: .5
    };
  }

  function eqfeed_callback(results) {
    map2.data.addGeoJson(results);

    for (var i = 0; i < results.features.length; i++) {
          var coords = results.features[i].geometry.coordinates;
          var latLng = new google.maps.LatLng(coords[1],coords[0]);
          var marker = new google.maps.Marker({
            position: latLng,
            map: map1
          });
        }
      }

