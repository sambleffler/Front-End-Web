var stopped = false;

function moveRight(){
		if (stopped == false) {
			document.getElementById('moveMe').style.textAlign = "right";
		}
	}

function moveLeft(){
		if (stopped == false) {
			document.getElementById('moveMe').style.textAlign = "left";
		}
	}

var button=document.getElementById("clickMe");
button.addEventListener("mouseover", moveRight);
button.addEventListener("mouseout",moveLeft);

function stop(){
	stopped = true;
	document.getElementById('moveMe').style.textAlign = "center";
}

function youWin() {
	document.getElementById('win').style.visibility = "visible";
}

var stopButton= document.getElementById("helpMe");
stopButton.addEventListener("click", stop);

button.addEventListener("click",youWin);
