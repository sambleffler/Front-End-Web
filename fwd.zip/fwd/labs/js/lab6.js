console.log("main.js connected");
if (window.jQuery) {console.log('jquery detected');}

new Vue({
	el:'#app',
	data: {
		pics:[],
		newURL:'',
		uploads:[]
	},
	methods: {
		saveImage: function(){
			let pic = {
		        url: this.newURL,
		        timestamp: this.date
		      };
			if(this.newURL.endsWith(".jpg") || this.newURL.endsWith(".png") || this.newURL.endsWith(".gif")){
				this.pics.push(pic);
				this.uploads.push(pic);
			}
			
			else{
				alert("Plese enter an image URL");
			}

			this.newURL='';
		},

		deleteImage: function(i){
			this.pics.splice(i,1);
			this.uploads.splice(i,1);
		},

		fillTrashIcon: function(event) {
	      event.target.classList.remove('fa-trash-o');
	      event.target.classList.add('fa-trash');
	    },

	    emptyTrashIcon: function(event) {
	      event.target.classList.remove('fa-trash');
	      event.target.classList.add('fa-trash-o');
	    }
	},
	computed:{
		
		date: function() {
	      let now = new Date().toLocaleTimeString();
	      return now;
	    }
	},
	watch:{

		uploads: function(newVal) {
      		let imgJSON = JSON.stringify(this.uploads);
      		window.localStorage.setItem('savedPic', imgJSON);
    	}

	},
	mounted:function(){
		if (window.localStorage.getItem('savedPic')) {
      		this.uploads = JSON.parse(window.localStorage.getItem('savedPic'));
      		for (let i = 0; i < this.uploads.length; i++) {
        		this.pics.push(this.uploads[i]);
      		}
    	}
	}

});