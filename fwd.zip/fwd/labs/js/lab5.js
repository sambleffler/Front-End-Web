// Get a reference to the database service
var database = firebase.database();

// Create a storage reference from our storage service
var storageRef = database.ref();


function sendSurvey(){

	var computer, soda, pet, phone, season;
	var name = document.getElementById("nameInput").value;

	if (document.getElementById("mac").checked==true) {
		computer = document.getElementById("mac").value;
	}

	else{
		computer = document.getElementById("pc").value;
	}

	if (document.getElementById("coke").checked==true) {
		soda = document.getElementById("coke").value;
	}

	else{
		soda = document.getElementById("pepsi").value;
	}

	if (document.getElementById("cat").checked==true) {
		pet = document.getElementById("cat").value;
	}

	else{
		pet = document.getElementById("dog").value;
	}

	if (document.getElementById("android").checked==true) {
		phone = document.getElementById("android").value;
	}

	else{
		phone = document.getElementById("iphone").value;
	}

	if (document.getElementById("summer").checked==true) {
		season = document.getElementById("summer").value;
	}

	else{
		season = document.getElementById("winter").value;
	}

	//write to firebase
	storageRef.push({
		name: name,
		computer: computer,
		soda: soda,
		pet: pet,
		phone: phone,
		season: season
	});
}

document.getElementById("submitButton").addEventListener("click", sendSurvey);

var surveyResults = document.getElementById("results");

// Adds an event listener to any child added to our database
// This is triggered when the listener is first attached and every time a new child is added
// Adds the orders to the orders div
	storageRef.on("child_added", function(snapshot){
			console.log(snapshot.val());
			var name=snapshot.val().name;
			var computer=snapshot.val().computer;
			var soda=snapshot.val().soda;
			var pet=snapshot.val().pet;
			var phone=snapshot.val().phone;
			var season=snapshot.val().season;
			surveyResults.innerHTML += "<span class='name'>" + name + ":</span> <span class='computer'>" + computer + ",</span> <span class='soda'>" + soda +",</span> <span class='pet'>" + pet +",</span> <span class='phone'>"+phone+",</span> <span class='season'>"+season+"</span><br>";
	});
