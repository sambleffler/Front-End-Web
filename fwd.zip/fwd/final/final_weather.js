jQuery(document).ready(function($) {
      $.ajax({
         url: "http://api.aerisapi.com/observations/whitefish,mt?client_id=aRLI8KsDzsyaV12cCVFTP&client_secret=BgLojH4xJANXrlRMCZfB7zSgpSD8wfP6WL1reqWw",
         dataType: "jsonp",
         success: function(json) {
            if (json.success == true) {
               var ob = json.response.ob;
               $('#currentWeather').html('The current weather in Whitefish is ' + ob.weather.toLowerCase() + ' with a temperature of ' + ob.tempF + '°' + ', a relative humidity of ' +ob.humidity+'% and wind speeds of ' + ob.windSpeedMPH+'mph.');
            }
            else {
               alert('An error occurred: ' + json.error.description);
            }
         }
      });
   });