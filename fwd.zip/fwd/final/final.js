// Get a reference to the database service
var database = firebase.database();

// Create a storage reference from our storage service
var storageRef = database.ref();

function sendResults(){
	var name, email, phone, see, trigger, caught, location, description;

	name = document.getElementById("name").value;
	email = document.getElementById("email").value;
	phone = document.getElementById("phone").value;

	if (document.getElementById("avalanche_yes").checked==true) {
		see = document.getElementById("avalanche_yes").value;
	}

	else{
		see = document.getElementById("avalanche_no").value;
	}

	if (document.getElementById("trigger_yes").checked==true) {
		trigger = document.getElementById("trigger_yes").value;
	}

	else{
		trigger = document.getElementById("trigger_no").value;
	}

	if (document.getElementById("caught_yes").checked==true) {
		caught = document.getElementById("caught_yes").value;
	}

	else{
		caught = document.getElementById("caught_no").value;
	}

	location = document.getElementById("location").value;
	description = document.getElementById("description").value;

	//write to firebase
	storageRef.push({
		name:name,
		email:email,
		phone:phone,
		see: see,
		trigger: trigger,
		caught: caught,
		location: location,
		description: description
	});
}

document.getElementById("enter").addEventListener("click", sendResults);

var surveyResults = document.getElementById("results");

// Adds an event listener to any child added to our database
// This is triggered when the listener is first attached and every time a new child is added
// Adds the orders to the orders div
	storageRef.on("child_added", function(snapshot){
			console.log(snapshot.val());
			var name=snapshot.val().name;
			var email=snapshot.val().email;
			var phone=snapshot.val().phone;
			var see=snapshot.val().see;
			var trigger=snapshot.val().trigger;
			var caught=snapshot.val().caught;
			var location=snapshot.val().location;
			var description=snapshot.val().description;
			surveyResults.innerHTML += "<span class='name'>" + name + "</span> <span class='email'>" + email + ",</span> <span class='phone'>" + phone +",</span> <span class='see'>" + see +",</span> <span class='trigger'>"+trigger+",</span> <span class='caught'>"+caught+"</span> <span class='location'>"+location+"</span> <span class='description'>"+description+"</span><br>";
});