var images=['images/scene1.jpg', 'images/scene2.jpg', 'images/scene3.jpg', 'images/scene4.jpg', 'images/scene5.jpg'];

function changeImage(){
	$('#sceneSlides').attr('src', images[Math.floor(Math.random() * images.length)]);
}

$(document).ready(function(){
	changeImage();
	$('#sceneSlides').click(changeImage);
});