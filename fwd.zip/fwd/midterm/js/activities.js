function showRock(){
	$('#rock').show(500);
	$('#cycle').hide(500);
	$('#ski').hide(500);
}

function showCycle(){
	$('#rock').hide(500);
	$('#cycle').show(500);
	$('#ski').hide(500);
}

function showSki(){
	$('#rock').hide(500);
	$('#cycle').hide(500);
	$('#ski').show(500);
}

$(document).ready(function(){
	$('#rockButton').click(showRock);
	$('#cycleButton').click(showCycle);
	$('#skiButton').click(showSki);
});