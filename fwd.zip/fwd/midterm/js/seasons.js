function showText(){
	if($(this).siblings('.season').css('display') == 'none'){
		$(this).siblings('.season').show(500);
		$(this).children('img').attr('src', 'images/uparrow.png')
	}

	else{
		$(this).siblings('.season').hide(500);
		$(this).children('img').attr('src', 'images/downarrow.png')
	}
}

$(document).ready(function(){
	$('h3').click(showText);
});